package editor;
import javax.swing.JOptionPane; 

public class About {

    public About() {

        JOptionPane.showMessageDialog(null, 
        "Package Done by 20pw10 - Dhivya Lakshmi and 20pw35 - Swetha Muralidharan ", 
        "About", JOptionPane.INFORMATION_MESSAGE);
        
    }

}